/**
 * @class       : Soma
 * @author      : Henrique Vital Carvalho (henriquevital1000@hotmail.com)
 * @created     : sábado out 24, 2020 18:15:19 -03
 * @description : Soma
 */

class Soma {
    calcula(a, b){
        return a+b;
    }
}

export default Soma;

