/**
 * @class       : Subtracao
 * @author      : Henrique Vital Carvalho (henriquevital1000@hotmail.com)
 * @created     : sábado out 24, 2020 18:16:11 -03
 * @description : Subtracao
 */

class Subtracao {
    calcula(a, b){
        return a-b;
    }
}

export default Subtracao;

