/**
 * @class       : Multiplicacao
 * @author      : Henrique Vital Carvalho (henriquevital1000@hotmail.com)
 * @created     : sábado out 24, 2020 18:17:38 -03
 * @description : Multiplicacao
 */

class Multiplicacao {
    calcula(a, b){
        return a*b;
    }
}

export default Multiplicacao;

