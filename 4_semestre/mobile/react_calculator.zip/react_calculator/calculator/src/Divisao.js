/**
 * @class       : Divisao
 * @author      : Henrique Vital Carvalho (henriquevital1000@hotmail.com)
 * @created     : sábado out 24, 2020 18:16:47 -03
 * @description : Divisao
 */

class Divisao {
    calcula(a, b){
        return a/b;
    }
}

export default Divisao;

